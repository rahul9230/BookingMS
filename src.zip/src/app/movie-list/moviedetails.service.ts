import { Injectable, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MoviedetailsService {
  
  
    $movieDetails = new EventEmitter();
    
    constructor() { }

    sendMovieDetails(movie){

      this.$movieDetails.emit(movie);

    }
}
