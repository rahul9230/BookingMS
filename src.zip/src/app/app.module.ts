import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieBookingComponent } from './movie-booking/movie-booking.component';
import { MovieBookingListComponent } from './movie-booking-list/movie-booking-list.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { HttpClientModule } from '@angular/common/http';
import { MovieTicketComponent } from './movie-ticket/movie-ticket.component';
import { ShowTicketComponent } from './show-ticket/show-ticket.component';
//import { DeleteBookingComponent } from './delete-booking/delete-booking.component';

@NgModule({
  declarations: [
    AppComponent,
    MovieBookingComponent,
    MovieBookingListComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    MovieListComponent,
    MovieTicketComponent,
    ShowTicketComponent,
  //  DeleteBookingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
