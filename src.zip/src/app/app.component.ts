import { Component } from '@angular/core';
import { MovieService } from './service/movie.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'booking-ms';

  service: MovieService;
    
    constructor(service:MovieService){
        this.service=service;
    }
    
    ngOnInit() {
       this.service.display();
    }
  
}
