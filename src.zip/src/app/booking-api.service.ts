import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket } from './Booking'
import { BookingList } from './BookingList';

@Injectable({
  providedIn: 'root'
})
export class BookingApiService {
    booking:Ticket;

    private baseUrl="http://localhost:8888/ticket/";

    constructor(private httpClient:HttpClient) { }
      

  public addTicket(booking:Ticket):Observable<Ticket>{
    return this.httpClient.post<Ticket>(this.baseUrl+"add/all",booking);
  }

  public showTicket(ticketId:number):Observable<any>{
    return this.httpClient.get(this.baseUrl+"id/"+ticketId);
  }

  public cancelBooking(ticketId:number):Observable<Ticket>{
    console.log("Ticket ID: "+ticketId +"has been Cancelled!") ;
    console.log(this.baseUrl+"delete/"+ticketId);
    return this.httpClient.delete<Ticket>(this.baseUrl+"/"+ticketId);
    
  }
 

  public  getAllBookings():Observable<BookingList>{
    return this.httpClient.get<BookingList>(this.baseUrl+"/all");
  }

}
