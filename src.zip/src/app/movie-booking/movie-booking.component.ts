

import { Component, OnInit } from '@angular/core';
import { BookingApiService } from '../booking-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Ticket } from '../Booking';

@Component({
  selector: 'app-movie-booking',
  templateUrl: './movie-booking.component.html',
  styleUrls: ['./movie-booking.component.css']
})
export class MovieBookingComponent implements OnInit {
  constructor(private router: Router, private bookingApiService: BookingApiService, private route: ActivatedRoute) { }
  booking: Ticket;
  ngOnInit(): void {
    this.booking = new Ticket();
  }
  addTicket() {
    this.route.params.subscribe(param => {
      this.booking.movieName = param['moviename'];
      this.booking.theatreName = param['theatrename']
    })
    this.bookingApiService.addTicket(this.booking).subscribe(
      (success) => {
        this.booking=success;
        console.log(success);
        alert("Booking Successfull!");
        this.router.navigate(["showticket/" + success.ticketId]);
       
      },
      (error) => {
        alert("Error:Booking Failed!");
      }
    )

    
     
    
  }
  validatephno(phno:number):Boolean
    {
      let a=phno.toString().length==10;
     
      return a;
    
    }
}
