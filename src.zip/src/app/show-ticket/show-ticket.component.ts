

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookingApiService } from '../booking-api.service';
import { Ticket } from 'src/app/Booking';

@Component({
  selector: 'app-show-ticket',
  templateUrl: './show-ticket.component.html',
  styleUrls: ['./show-ticket.component.css']
})
export class ShowTicketComponent implements OnInit {

  constructor(private bookingApiService:BookingApiService,private route:ActivatedRoute) { }
  booking: Ticket;
  ticketId:number;

  ngOnInit(): void {
    this.route.params.subscribe(
      (param)=>{
        this.searchBooking(param["id"]);
      }
    )
  }

  

searchBooking(ticketId){
      this.bookingApiService.showTicket(ticketId).subscribe(
        (booking)=>{
          this.booking=booking;
          console.log(booking);
        }
        
      );
  }

  cancelBooking(ticketId){
    if(confirm("Are you sure to Cancel?")){
      this.bookingApiService.cancelBooking(ticketId).subscribe(
        (success)=>{
             alert("Your Booking with BookingID ["+ticketId+"] is Cancelled");
            this.ngOnInit(); 
            },
        (error)=>{
          alert("Cancellation Failed");
        }
      );
    }
  }
}