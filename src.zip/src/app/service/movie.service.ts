import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

 //BEANS//
    
    export class Movie{
        constructor(
            public name:string,
            public theatre:string,
        ) {}
    }

    export class Ticket{
        constructor(
             public ticketId:number,
             public noOfSeats:number,
             public seatNo:number,
             public movieName:String,
             public theatreName:String,
             public customerName:String,
             public emailId:String,
             public phno:number,
             public paymentMethod:String,
         
         ){}
    }

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  movies:Movie[]=[];
  
  booking:Ticket = new Ticket(0,0,0,"","","","",0,"");

  bookingList : Ticket[];
  
  //To emit entered booking details to another component
  $bookingDetails = new EventEmitter();

   //Constructor Injections for HttpClient(to handle request and response)
    constructor(private httpClient:HttpClient , private router: Router) { } 

      //Storing Movie List from json file
      display(){
            this.httpClient.get<Movie[]>('./assets/Movies.json').subscribe(response =>{
                for(let m of response){
                let movie = new Movie(m.name,m.theatre);
                this.movies.push(movie);
                }
              }
            );
       } 

       //Getting Movie List
       getMovies(): Movie[]{
           return this.movies;
       }
  
      //Setting Movie And Theatre
       setMovieDetails(movie){
       console.log("Changing From Movie to Booking Done");
       this.booking.movieName = movie.name;
       this.booking.theatreName = movie.theatre;
       console.log(this.booking);
      }
      
      //Adding The New Booking to Database using POST 
      addTicket(bookingfinal):Observable<Ticket> {
      this.booking.customerName = bookingfinal.customerName;
      this.booking.emailId = bookingfinal.emailId;
      this.booking.paymentMethod = bookingfinal.paymentMethod;
      this.booking.phno = bookingfinal.phno;
      this.booking.noOfSeats = bookingfinal.noOfSeats;
      console.log(this.booking);
      this.$bookingDetails.emit(this.booking);
      this.router.navigate(['/movieticket']);
          
          return this.httpClient.post<Ticket>("http://localhost:8888/ticket/add/all", this.booking);
      }

      //Retreiving the booking list from Database using GET Method
      getAllBookings(){
          return this.httpClient.get<Ticket[]>("http://localhost:8888/ticket/all");
      }

      //Delete Particular Booking by sending particular ID 
      cancelBooking(booking){
           return this.httpClient.delete<Ticket>("http://localhost:8888/ticket"+"/"+booking.ticketId);
      }

      showTicket(ticketId){
        return this.httpClient.get<Ticket>("http://localhost:8888/ticket/id"+"/"+ticketId);
      }
}
 
