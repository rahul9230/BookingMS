import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    username:string;
    password:string;

  constructor( private router: Router ) { }

  ngOnInit(): void {
  }
  
  LoginUser():any
  {
      //Hardcoded Credentials for time being..
      if(this.username == "rahul9" && this.password == "rahul9")    
      {
        alert("Successfully logged In..    Happy Booking! ^_^ ")
       
        this.router.navigate(['/movielist']);
      }
      else
      {
        console.log("Invalid credentials");
        alert("Login Failed....Please provide Registered Credentials.");
      }
  }

}
