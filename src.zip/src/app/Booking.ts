

export class Ticket{
                                      
                                     
    public ticketId:number;
    public noOfSeats:number;
    public movieName:String;
    public theatreName:String;    
	public customerName:String;
    public emailId:String;
    public phno:number;
    public paymentMethod:String;
    
} 