import { Ticket } from './service/movie.service';

export class BookingList
{
    public bookingList:Ticket[];
}