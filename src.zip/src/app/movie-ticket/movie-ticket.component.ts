import { Component, OnInit } from '@angular/core';
import { MovieService, Ticket } from '../service/movie.service';

export interface Ticket1{
  ticketId:number,
  movieName:string,
  theatreName:string,
  customerName:string,
  emailId:string,
  phno:string,
  paymentMethod:string,
  seats:number 
  toString() :string
}

@Component({
  selector: 'app-movie-ticket',
  templateUrl: './movie-ticket.component.html',
  styleUrls: ['./movie-ticket.component.css']
})
export class MovieTicketComponent implements OnInit {
  
  booking : Ticket = new Ticket(0,0,0,"","","","",0,"");
  public booking1 : Ticket1 ;
  constructor(private service: MovieService) { }

  ngOnInit(){
      this.service.$bookingDetails.subscribe( (data) => {
        this.booking1 = data ;
        console.log(this.booking1);
       
      })
  }
  settoString(){
    this.booking1.toString = function() {
      return 'your name is ${this.customerName}' ;
    }   
  }
  
}
